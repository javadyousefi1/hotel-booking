const config = Object.freeze({
    maxAge: 3600000,
    authToken: "token"
})

export default config